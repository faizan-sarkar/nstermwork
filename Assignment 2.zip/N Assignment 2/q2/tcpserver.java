import java.util.*;
import java.io.*;
import java.net.*;
import java.sql.*;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class tcpserver
{
	public static void main(String args[]) throws IOException
	{
		ServerSocket ds=new ServerSocket(1234);	
			String un,p,eun,ep;
			Socket sk=ds.accept();
			BufferedReader br=new BufferedReader(new InputStreamReader(sk.getInputStream()));
			eun=br.readLine();
			ep=br.readLine();
			un=decrypt(eun,5);
			p=decrypt(ep,5);
			System.out.println("Received Encrypted Username: "+eun);
			System.out.println("Received Encrypted Password: "+ep);	
			System.out.println("Decrypted Username: "+un);
			System.out.println("Decrypted Password: "+p);	
			String hp=md5(p);
			int index=Integer.parseInt(hp.charAt((hp.length()-1))+"",16);
			index=index%10;
			System.out.println("Hash of password: "+hp+" :"+index);
			DataOutputStream dos=new DataOutputStream(sk.getOutputStream());
			try
			{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ns","root","");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from q2user");
			rs.next();			
			System.out.println(rs.getInt("uid"));
			rs.absolute(index);
			System.out.println(rs.getInt("uid"));
			if(un.equals(rs.getString("uname")) && p.equals(rs.getString("pass")))
			{
				dos.writeBytes("Successfully logged in!\n");
					return;
			}
			rs.close();
			dos.writeBytes("Invalid Login details!\n");
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
	}
	public static String decrypt(String s, int k)
	{
		StringBuilder sb=new StringBuilder();
		char c;
		for(int i=0; i<s.length(); i++)
		{
			if((s.charAt(i)>='a' && s.charAt(i)<='z') || (s.charAt(i)>='A' && s.charAt(i)<='Z'))
			{
				if(s.charAt(i)>=(122-(k-1)))
				{
					c=(char)(s.charAt(i)-(26-k));
					sb.append(c);
					continue;					
				}
				else if(s.charAt(i)>=(90-(k-1)) && s.charAt(i)<=90)
				{
					c=(char)(s.charAt(i)-(26-k));
					sb.append(c);
					continue;
				}
				c=(char)(s.charAt(i)+k);
				sb.append(c);
				continue;
			}
			else if(s.charAt(i)>='0' && s.charAt(i)<='9')
			{
				if(s.charAt(i)>=57-(k-1))
				{
					c=(char)(s.charAt(i)-(10-k));
					sb.append(c);
					continue;					
				}
				c=(char)(s.charAt(i)+k);
				sb.append(c);
				continue;
			}
			sb.append(s.charAt(i));
		}
		return sb.toString();
	}
	public static String md5(String input) 
	{
		String md5 = null;
		if(null == input) return null;
		try {
			//Create MessageDigest object for MD5
			MessageDigest digest = MessageDigest.getInstance("MD5");
			//Update input string in message digest
			digest.update(input.getBytes(), 0, input.length());
			//Converts message digest value in base 16 (hex) 
			md5 = new BigInteger(1, digest.digest()).toString(16);
		}
		catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return md5;
	}
}
