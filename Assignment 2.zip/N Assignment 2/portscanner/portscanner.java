import java.net.*;

public class portscanner
{
	public static void main(String args[])
	{
		for(int i=1; i<=65535; i++)
		{
			try
			{
				Socket s=new Socket();
				s.connect(new InetSocketAddress("localhost",i),1000);
				s.close();
				System.out.println("Port "+i+" is open!");				
			}
			catch(Exception e)
			{
				//System.out.println("Port "+i+" is not open!");	
			}
		}
	}
}