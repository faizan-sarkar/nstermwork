import java.util.*;
import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class udpfirewall
{
	public static void main(String args[]) throws IOException
	{
		DatagramSocket ds=new DatagramSocket(1233);
		DatagramSocket ds1=new DatagramSocket();
		InetAddress ip=InetAddress.getLocalHost();
		byte buf[]=new byte[65535];
		byte buf1[]=new byte[65535];
		String s;
		DatagramPacket dp=new DatagramPacket(buf,buf.length);
		ds.receive(dp);
		s=new String(buf).trim();
		System.out.println("String successfully received by Firewall: "+s);
		if(checkString(s)==null)
		{
			buf1=s.getBytes();
			DatagramPacket dp1=new DatagramPacket(buf1,buf1.length,ip,1234);
			ds1.send(dp1);			
		}
		else
		{
			System.out.println("String "+s+" Not Sent!");
			System.out.println("Illegal Word is used in the String to be sended: "+checkString(s));
		}		
	}
	
	public static String checkString(String s)throws IOException
	{
		BufferedReader br=new BufferedReader(new FileReader("keywords.txt"));
		String temp="";
		while((temp=br.readLine())!=null)
		{
			if((s.toUpperCase()).contains(temp))
			{
				return temp;
			}
		}
		return null;
	}
}
