import java.util.*;
import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class udp
{
	public static void main(String args[]) throws IOException
	{
		Scanner sc=new Scanner(System.in);
		DatagramSocket ds=new DatagramSocket();
		InetAddress ip=InetAddress.getLocalHost();
		byte buf[]=null;
		String s;
		System.out.println("Enter String to be Sent: ");
		s=sc.nextLine();
		buf=s.getBytes();
		DatagramPacket dp=new DatagramPacket(buf,buf.length,ip,1233);
		ds.send(dp);
		System.out.println("String: "+s+" sent Successfully!");
	}
}
